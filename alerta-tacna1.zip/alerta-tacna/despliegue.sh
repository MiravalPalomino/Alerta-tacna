#!/bin/bash
# Ejecutar en la EC2 (Amazon Linux 2023) dentro de la carpeta del proyecto
sudo dnf install -y python3-pip git
pip3 install -r requirements.txt
cp .env.example .env && nano .env        # editar con el endpoint de RDS
set -a; source .env; set +a
python3 init_db.py                       # crea tablas + admin
sudo tee /etc/systemd/system/alerta.service >/dev/null <<UNIT
[Unit]
Description=Alerta Tacna
After=network.target
[Service]
User=ec2-user
WorkingDirectory=$(pwd)
EnvironmentFile=$(pwd)/.env
ExecStart=/usr/local/bin/gunicorn -w 2 -b 0.0.0.0:80 app:app
AmbientCapabilities=CAP_NET_BIND_SERVICE
Restart=always
[Install]
WantedBy=multi-user.target
UNIT
sudo systemctl daemon-reload && sudo systemctl enable --now alerta
echo "Listo: http://<IP-PUBLICA-EC2>/"
